# Databricks notebook source
# MAGIC %md-sandbox
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png" alt="Databricks Learning" style="width: 600px">
# MAGIC </div>

# COMMAND ----------

# DBTITLE 0,--i18n-263caa08-bb08-4022-8d8f-bd2f51d77752
# MAGIC %md 
# MAGIC
# MAGIC
# MAGIC
# MAGIC # Classification: Logistic Regression
# MAGIC
# MAGIC Up until this point, we have only examined regression use cases. Now let's take a look at how to handle classification.
# MAGIC
# MAGIC For this lab, we will use the same Airbnb dataset, but instead of predicting price, we will predict if host is a <a href="https://www.airbnb.com/superhost" target="_blank">superhost</a> or not in San Francisco.
# MAGIC
# MAGIC ## ![Spark Logo Tiny](https://files.training.databricks.com/images/105/logo_spark_tiny.png) Learning Objectives:<br>
# MAGIC
# MAGIC By the end of this lesson, you should be able to;
# MAGIC
# MAGIC  - Build a Logistic Regression model
# MAGIC  - Use various metrics to evaluate model performance

# COMMAND ----------

# DBTITLE 0,--i18n-1e2c921e-1125-4df3-b914-d74bf7a73ab5
# MAGIC %md 
# MAGIC ## 📌 Requirements
# MAGIC
# MAGIC **Required Databricks Runtime Version:** 
# MAGIC * Please note that in order to run this notebook, you must use one of the following Databricks Runtime(s): **12.2.x-cpu-ml-scala2.12**

# COMMAND ----------

# DBTITLE 0,--i18n-6a1bb996-7b50-4f03-9bcd-3d3ec3069a6d
# MAGIC %md 
# MAGIC ## Lesson Setup
# MAGIC
# MAGIC The first thing we're going to do is to **run setup script**. This script will define the required configuration variables that are scoped to each user.

# COMMAND ----------

# MAGIC %run "../Includes/Classroom-Setup"

# COMMAND ----------

# DBTITLE 0,--i18n-2340cdf4-9753-41b4-a613-043b90f0f472
# MAGIC %md 
# MAGIC
# MAGIC ## Load Dataset

# COMMAND ----------

file_path = f"{DA.paths.datasets}/airbnb/sf-listings/sf-listings-2019-03-06-clean.delta/"
airbnb_df = spark.read.format("delta").load(file_path)

# COMMAND ----------

# DBTITLE 0,--i18n-3f07e772-c15d-46e4-8acd-866b661fbb9b
# MAGIC %md 
# MAGIC
# MAGIC
# MAGIC
# MAGIC ## Baseline Model
# MAGIC
# MAGIC Before we build any Machine Learning models, we want to build a baseline model to compare to. We are going to start by predicting if a host is a <a href="https://www.airbnb.com/superhost" target="_blank">superhost</a>. 
# MAGIC
# MAGIC For our baseline model, we are going to predict no on is a superhost and evaluate our accuracy. We will examine other metrics later as we build more complex models.
# MAGIC
# MAGIC 0. Convert our **`host_is_superhost`** column (t/f) into 1/0 and call the resulting column **`label`**. DROP the **`host_is_superhost`** afterwards.
# MAGIC 0. Add a column to the resulting DataFrame called **`prediction`** which contains the literal value **`0.0`**. We will make a constant prediction that no one is a superhost.
# MAGIC
# MAGIC After we finish these two steps, then we can evaluate the "model" accuracy. 
# MAGIC
# MAGIC Some helpful functions:
# MAGIC * <a href="https://spark.apache.org/docs/latest/api/python/reference/pyspark.sql/api/pyspark.sql.functions.when.html" target="_blank">when()</a>
# MAGIC * <a href="https://spark.apache.org/docs/latest/api/python/reference/pyspark.sql/api/pyspark.sql.DataFrame.withColumn.html" target="_blank">withColumn()</a>
# MAGIC * <a href="https://spark.apache.org/docs/latest/api/python/reference/pyspark.sql/api/pyspark.sql.functions.lit.html" target="_blank">lit()</a>

# COMMAND ----------

# TODO
from <FILL_IN>

label_df = airbnb_df.<FILL_IN>

pred_df = label_df.<FILL_IN> # Add a prediction column

# COMMAND ----------

# DBTITLE 0,--i18n-d04eb817-2010-4021-a898-42ca8abaa00d
# MAGIC %md 
# MAGIC
# MAGIC
# MAGIC
# MAGIC ## Evaluate model
# MAGIC
# MAGIC For right now, let's use accuracy as our metric. This is available from <a href="https://spark.apache.org/docs/latest/api/python/reference/api/pyspark.ml.evaluation.MulticlassClassificationEvaluator.html?highlight=multiclassclassificationevaluator#pyspark.ml.evaluation.MulticlassClassificationEvaluator" target="_blank">MulticlassClassificationEvaluator</a>.

# COMMAND ----------

from pyspark.ml.evaluation import MulticlassClassificationEvaluator

mc_evaluator = MulticlassClassificationEvaluator(metricName="accuracy")
print(f"The accuracy is {100*mc_evaluator.evaluate(pred_df):.2f}%")

# COMMAND ----------

# DBTITLE 0,--i18n-5fe00f31-d186-4ab8-b6bb-437f7ddc4a00
# MAGIC %md 
# MAGIC
# MAGIC
# MAGIC
# MAGIC ## Train-Test Split
# MAGIC
# MAGIC Alright! Now we have built a baseline model. The next step is to split our data into a train-test split.

# COMMAND ----------

train_df, test_df = label_df.randomSplit([.8, .2], seed=42)
print(train_df.cache().count())

# COMMAND ----------

# DBTITLE 0,--i18n-a7998d44-af91-4dfa-b80c-8b96ebfe5311
# MAGIC %md 
# MAGIC
# MAGIC
# MAGIC
# MAGIC ## Visualize
# MAGIC
# MAGIC Let's look at the relationship between **`review_scores_rating`** and **`label`** in our training dataset.

# COMMAND ----------

display(train_df.select("review_scores_rating", "label"))

# COMMAND ----------

# DBTITLE 0,--i18n-1ce4ba05-f558-484d-a8e8-53bde1e119fc
# MAGIC %md 
# MAGIC
# MAGIC
# MAGIC
# MAGIC ## Logistic Regression
# MAGIC
# MAGIC Now build a <a href="https://spark.apache.org/docs/latest/api/python/reference/api/pyspark.ml.classification.LogisticRegression.html?highlight=logisticregression#pyspark.ml.classification.LogisticRegression" target="_blank">logistic regression model</a> using all of the features (HINT: use RFormula). Put the pre-processing step and the Logistic Regression Model into a Pipeline.

# COMMAND ----------

# TODO
from pyspark.ml import Pipeline
from pyspark.ml.feature import RFormula
from pyspark.ml.classification import LogisticRegression

r_formula = RFormula(<FILL_IN>)
lr = <FILL_IN>
pipeline = Pipeline(<FILL_IN>)
pipeline_model = pipeline.fit(<FILL_IN>)
pred_df = pipeline_model.transform(<FILL_IN>)

# COMMAND ----------

# DBTITLE 0,--i18n-3a06d71c-8551-44c8-b33e-8ae40a443713
# MAGIC %md 
# MAGIC
# MAGIC
# MAGIC
# MAGIC ## Evaluate
# MAGIC
# MAGIC What is AUROC useful for? Try adding additional evaluation metrics, like Area Under PR Curve.

# COMMAND ----------

# TODO
from pyspark.ml.evaluation import BinaryClassificationEvaluator, MulticlassClassificationEvaluator

mc_evaluator = MulticlassClassificationEvaluator(metricName="accuracy")
print(f"The accuracy is {100*mc_evaluator.evaluate(pred_df):.2f}%")

bc_evaluator = BinaryClassificationEvaluator(metricName="areaUnderROC")
print(f"The area under the ROC curve: {bc_evaluator.evaluate(pred_df):.2f}")

# COMMAND ----------

# DBTITLE 0,--i18n-0ef0e2b9-6ce9-4377-8587-83b5260fd05a
# MAGIC %md 
# MAGIC
# MAGIC
# MAGIC
# MAGIC ## Add Hyperparameter Tuning
# MAGIC
# MAGIC Try changing the hyperparameters of the logistic regression model using the cross-validator. By how much can you improve your metrics?

# COMMAND ----------

# TODO
from pyspark.ml.tuning import ParamGridBuilder
from pyspark.ml.tuning import CrossValidator

param_grid = <FILL_IN>

evaluator = <FILL_IN>

cv = <FILL_IN>

pipeline = <FILL_IN>

pipeline_model = <FILL_IN>

pred_df = <FILL_IN>

# COMMAND ----------

# DBTITLE 0,--i18n-111f2dc7-5535-45b7-82f6-ad2e5f2cbf16
# MAGIC %md 
# MAGIC
# MAGIC
# MAGIC
# MAGIC ## Evaluate again

# COMMAND ----------

mc_evaluator = MulticlassClassificationEvaluator(metricName="accuracy")
print(f"The accuracy is {100*mc_evaluator.evaluate(pred_df):.2f}%")

bc_evaluator = BinaryClassificationEvaluator(metricName="areaUnderROC")
print(f"The area under the ROC curve: {bc_evaluator.evaluate(pred_df):.2f}")

# COMMAND ----------

# DBTITLE 0,--i18n-7e88e044-0a34-4815-8eab-1dc37532a082
# MAGIC %md 
# MAGIC
# MAGIC
# MAGIC
# MAGIC ## Super Bonus
# MAGIC
# MAGIC Try using MLflow to track your experiments!

# COMMAND ----------

# DBTITLE 0,--i18n-a2c7fb12-fd0b-493f-be4f-793d0a61695b
# MAGIC %md 
# MAGIC
# MAGIC ## Classroom Cleanup
# MAGIC
# MAGIC Run the following cell to remove lessons-specific assets created during this lesson:

# COMMAND ----------

DA.cleanup()

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC &copy; 2024 Databricks, Inc. All rights reserved.<br/>
# MAGIC Apache, Apache Spark, Spark and the Spark logo are trademarks of the <a href="https://www.apache.org/">Apache Software Foundation</a>.<br/>
# MAGIC <br/>
# MAGIC <a href="https://databricks.com/privacy-policy">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use">Terms of Use</a> | <a href="https://help.databricks.com/">Support</a>